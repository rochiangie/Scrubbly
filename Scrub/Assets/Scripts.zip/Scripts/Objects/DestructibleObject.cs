using UnityEngine;

// Aseg�rate de que el objeto que use este script tenga un Collider con isTrigger = true
// e implementa la interfaz IAttackable para ser compatible con PlayerInteraction.cs
public class DestructibleObject : MonoBehaviour, IAttackable
{
    // --- Configuraci�n del Objeto ---
    // Quitamos la variable 'puntosDeValorSentimental' porque estos objetos
    // solo contribuyen a la limpieza (DirtCleaned), no al score sentimental.
    // [Header("Configuraci�n de Destrucci�n")]
    // public int puntosDeValorSentimental = 5; 

    [Header("Efectos")]
    [Tooltip("El Prefab del sistema de part�culas a instanciar al destruir.")]
    public GameObject prefabParticulas;
    [Tooltip("El clip de audio a reproducir al destruir.")]
    public AudioClip sonidoDeDestruccion;

    private AudioSource audioSource;
    private bool isDestroyed = false;

    void Start()
    {
        // Se asegura de tener un AudioSource en el objeto para reproducir el sonido
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
        audioSource.playOnAwake = false; // Importante para que no suene al inicio
    }

    // M�todo requerido por IAttackable, llamado por PlayerInteraction cuando se ataca con 'F' estando cerca.
    public void ReceiveAttack()
    {
        if (isDestroyed) return; // Evita doble destrucci�n

        isDestroyed = true;

        // 1. Sonido y Part�culas
        if (sonidoDeDestruccion != null)
        {
            // Reproduce el sonido una sola vez
            audioSource.PlayOneShot(sonidoDeDestruccion);
        }

        if (prefabParticulas != null)
        {
            // Instancia las part�culas en la posici�n del objeto
            Instantiate(prefabParticulas, transform.position, Quaternion.identity);
        }

        // 2. Notificaci�n de Limpieza para el TaskManager
        // Esto incrementa el contador de limpieza general.
        GameEvents.DirtCleaned();

        // 3. Destrucci�n del Objeto (con un peque�o retraso para que el sonido termine)
        Destroy(gameObject, 0.5f);
    }
}