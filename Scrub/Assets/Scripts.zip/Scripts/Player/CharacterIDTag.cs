using UnityEngine;

public class CharacterIDTag : MonoBehaviour
{
    [Header("Identificaci�n del Personaje")]
    public string characterID; // ID �nico para m�sica (ej: "Maid", "Butler")
    public string displayName; // Nombre para mostrar en UI
}