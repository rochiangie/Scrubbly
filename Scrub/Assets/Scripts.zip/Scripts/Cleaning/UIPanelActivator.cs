using UnityEngine;

public class UIPanelActivator : MonoBehaviour
{
    // Asigna el GameObject del panel aqu�
    [SerializeField] private GameObject trashPanel;

    // Puedes hacer un m�todo p�blico para activarlo
    public void ShowPanel()
    {
        if (trashPanel != null)
        {
            trashPanel.SetActive(true);
        }
    }

    // Y otro para desactivarlo
    public void HidePanel()
    {
        if (trashPanel != null)
        {
            trashPanel.SetActive(false);
        }
    }
}