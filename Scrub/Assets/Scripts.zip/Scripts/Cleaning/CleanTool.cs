// CleanTool.cs
using UnityEngine;

public class CleanTool : MonoBehaviour
{
    // [Cualquier l�gica de limpieza o variables]

    // Este es el m�todo que ToolHandler intenta llamar
    public void Clean()
    {
        Debug.Log("La herramienta est� limpiando.");
        // Aqu� va la l�gica para interactuar con la suciedad cercana.
    }
}